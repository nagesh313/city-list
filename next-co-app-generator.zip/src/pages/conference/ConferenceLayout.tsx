const ConferenceLayout = ({ children }: any) => {
  return (
    <>
      <header>
        <h1>ConferenceLayout</h1>
      </header>
      <section>{children}</section>
      <footer>footer</footer>
    </>
  );
};

export default ConferenceLayout;