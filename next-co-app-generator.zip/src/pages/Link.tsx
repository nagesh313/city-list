import Link from "next/link";

const Links = () => {
  return (
    <div>
      <Link href="/home">HOME</Link>
      <Link href="/blog">BLOG</Link>
      <Link href="/settings">SETTINGS</Link>
      <Link href="/conference">CONFERENCE</Link>
    </div>
  );
};
export default Links;